<?php require('include/header.inc.php');
  $plan = array("Basic","Standard","Premium");
  $status = array("Blocked","Active");
?>

<?php

  if(isset($_GET['action'])) {
    // blocking a customer
    if($_GET['action'] == "block") {
      $sql = "UPDATE user SET user_status=0 WHERE user_id=".$_GET['id'];
      if(mysqli_query($conn,$sql)) {
        echo "Blocked Successfully";
        redirect('customer.php');
      }
      else {
        echo "Error in blocking";
      }
    }
    else if($_GET['action'] == "delete") {
      // // deleting the customer
      $sql = "DELETE FROM user WHERE user_id=".$_GET['id'];
      if(mysqli_query($conn,$sql)) {
        echo "Deleted Successfully";
        redirect('customer.php');
      }
      else {
        echo "Error in deletion";
      }
    }
  }
  if(isset($_POST['addCus'])) {
    $addCustomer = $conn->prepare("INSERT INTO user (user_name, user_email, user_role, user_addr, user_status, user_contact, user_age, user_sex) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $addCustomer->bind_param("ssdsdsds", $cName, $cEmail, $cRole, $cAddr, $cStatus, $cContact, $cAge, $cGender);
    $cName = mysqli_real_escape_string($conn, $_POST['cName']);
    $cEmail = mysqli_real_escape_string($conn, $_POST['cEmail']);
    $cAddr = mysqli_real_escape_string($conn, $_POST['cAddr']);
    $cContact = mysqli_real_escape_string($conn, $_POST['cContact']);
    $cGender = mysqli_real_escape_string($conn, $_POST['cGender']);
    $cAge = mysqli_real_escape_string($conn, $_POST['cAge']);
    $cRole = 3;
    $cStatus = 1;
    if($addCustomer->execute()) {
      echo "Inserted Successfully";
      unset($_POST);
    }
    else {
      echo "Fir wahi chutzpa";
    }
    $addCustomer->close();
  }
?>



  <div class="container cbody" style="padding-top:10px;">

    <div class="row">
      <div class="col-6">
        <button type="button" class="btn btn-lg btn-primary" data-toggle="modal" data-target="#exampleModalCenter">Add New Customer</button>
      </div>
      <div class="col-6">
        <!-- <?php
          if($isFlash) {
            echo $flashMsg;
          }
        ?> -->
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add a new Customer</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" method="POST">
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label>Customer Name</label>
                  <input type="text" name="cName" class="form-control" placeholder="Customer Name">
                </div>
                <div class="form-group col-md-6">
                  <label >Email</label>
                  <input type="text" name="cEmail" class="form-control" placeholder="Customer Email">
                </div>
              </div>
              <div class="form-group">
                <label>Address</label>
                <input type="text" name="cAddr" class="form-control"  placeholder="1234 Main St">
              </div>

              <div class="form-row">
                <div class="form-group col-md-4">
                  <label>Contact Number</label>
                  <input type="text" name="cContact" class="form-control" placeholder="+91 98765-54321">
                </div>
                <div class="form-group col-md-4">
                  <label>Age</label>
                  <input type="text" name="cAge" class="form-control" placeholder="XX">
                </div>
                <div class="form-group col-md-4">
                  <label>Gender</label>
                  <select class="form-control" name="cGender">
                    <option selected>Choose...</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Others">Others</option>
                  </select>
                </div>
              </div>
              <!-- <div class="form-group">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="isChecked">
                  <label class="form-check-label" for="gridCheck">
                    Check me out
                  </label>
                </div>
              </div> -->
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                <input type="submit" class="btn btn-success" value="Add new Customer" name="addCus">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Model Ends here -->

          <?php
            $sql = 'SELECT * FROM user WHERE user_role=3';
            $result = mysqli_query($conn,$sql);
            $i = 1;
            if(mysqli_num_rows($result)>0) {
              echo '<table class="table table-striped table-bordered" style="margin-top:10px;">
                  <thead class="thead-dark">
                    <tr>
                      <th>S. No.</th>
                      <th>Customer Name</th>
                      <th>Customer Address</th>
                      <th>Email Address</th>
                      <th>Age</th>
                      <th>Contact No.</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>

                  <tbody>';

              while($row = mysqli_fetch_assoc($result)) {
                echo '
                  <tr>
                    <td>'.$i++.'. </td>
                    <td>'.$row['user_name'].'</td>
                    <td>'.$row['user_addr'].'</td>
                    <td>'.$row['user_contact'].'</td>
                    <td>'.$row['user_age'].'</td>
                    <td>'.$row['user_contact'].'</td>
                    <td>'.$status[$row['user_status']].'</td>
                    <td><a href="editCustomer.php?id='.$row['user_id'].'"><i class="far fa-edit"></i> Edit</a>&nbsp;&nbsp;
                    <a href="?action=block&id='.$row['user_id'].'"><i class="fa fa-ban"></i> block</a>&nbsp;&nbsp;
                    <a href="?action=delete&id='.$row['user_id'].'"><i class="fa fa-trash"></i> Delete</a></td>
                  </tr>
                ';
              }
            }
            else {
              echo "NO COMPANIES ADDED YET.";
            }
          ?>
        </tbody>
      </table>


  </div>


<?php require('include/footer.inc.php'); ?>
