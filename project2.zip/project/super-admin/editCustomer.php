<?php require('include/header.inc.php'); ?>
<!--  start here -->




<div class="container" style="padding-top:10px;">
  <h2>Edit Customer</h2><hr>
  <form action="" method="POST">
    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Company Name</label>
        <input type="text" name="companyName" class="form-control" placeholder="Company Name">
      </div>
      <div class="form-group col-md-6">
        <label >Password</label>
        <input type="text" name="companyPwd" class="form-control" placeholder="Password">
      </div>
    </div>
    <div class="form-group">
      <label>Address</label>
      <input type="text" name="companyAddr" class="form-control"  placeholder="1234 Main St">
    </div>

    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Contact Number</label>
        <input type="text" name="companyContact" class="form-control" placeholder="+91 98765-54321">
      </div>
      <div class="form-group col-md-6">
        <label>Choose Pricing Plan</label>
        <select class="form-control" name="companyPricing">
          <option selected>Choose...</option>
          <option value="1">Basic</option>
          <option value="2">Standard</option>
          <option value="3">Premium</option>
        </select>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
      <input type="submit" class="btn btn-success" value="Add new Company" name="addCom">
    </div>
  </form>
</div>
<!-- end here -->
<?php require('include/footer.inc.php'); ?>
