<?php require('../config/functions.inc.php');
      require('../config/db.inc.php');

?>
