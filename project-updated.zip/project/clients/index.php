<?php
  require('../config/functions.inc.php');
  echo "Hello Client";

  print_r($_SESSION);

 ?>
