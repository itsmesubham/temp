<?php
  require('config/db.inc.php');
  require('config/functions.inc.php');
?>

<?php
  $err = 0;
  $errMsg = "";
  $user_role = "";
  if(isset($_POST['login'])) {

    $username = test_input($_POST['name']);
    $password = test_input($_POST['password']);

    if($username == "" || $password == "") {
      $err = 1;
      $errMsg = "Username/Password are empty.";    // Empty email & password handling
    }
    $sql = "SELECT * FROM user WHERE user_name='".$username."'";
    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0) {
      while($data = mysqli_fetch_assoc($result)) {
        if($data['user_password'] == $password) {
          $_SESSION = $data;
          //print_r($_SESSION);

          $user_role = $_SESSION['user_role'];

          if ($_SESSION['user_role'] == 1) {
            redirect('./super-admin');
          }
          else if ($_SESSION['user_role'] == 2) {
            redirect('./admin');
          }
          else if ($_SESSION['user_role'] == 3) {
            redirect('./customer');
          }
        }
        else {
          $err = 1;
          $errMsg = "Wrong Password";
        }
      }
    }
    else
      $err = 1;      // If email & password unmatched.
      $errMsg = "User doesn't exist.";
  }


  if ($user_role == 1) {
    redirect('./super-admin');
  }
  else if ($user_role == 2) {
    redirect('./admin');
  }
  else if ($user_role == 3) {
    redirect('./customer');
  }



?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Project</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/super-admin.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
  </head>
  <body>
    <div class="row mt-5">
      <div class="col-md-6 m-auto">
        <div class="card card-body bg-light">
          <h1 class="text-center mb-3"><i class="fas fa-sign-in-alt"></i>  Login</h1>
          <form action="." method="POST">
            <div class="form-group">
              <label for="email">Email</label>
              <input
                type="text"
                id="email"
                name="name"
                class="form-control"
                placeholder="Enter Email"
              />
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                class="form-control"
                placeholder="Enter Password"
              />
            </div>
            <input type="submit" name="login" class="btn btn-primary btn-block" value="Login">
          </form>
          <p class="lead mt-4">
            No Account? <a href="register.php">Register</a>
          </p>
        </div>
      </div>
    </div>
    <?php if($err) {
      echo '<h1>'.$errMsg.'</h1>';
    } ?>

  </body>
  <script type="text/javascript" src="assets/js/bootstrap.js"></script>
</html>
