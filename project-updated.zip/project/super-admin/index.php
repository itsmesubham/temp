<?php require('include/header.inc.php'); ?>

<div class="container">
  <h1>Hello</h1>
</div>


<?php require('include/footer.inc.php'); ?>
