<?php require('include/header.inc.php'); ?>
<!--  start here -->

<?php

  if(isset($_POST['updateCom'])) {
    $companyName = mysqli_real_escape_string($conn, $_POST['companyName']);
    $companyAddr = mysqli_real_escape_string($conn, $_POST['companyAddr']);
    $companyContact = mysqli_real_escape_string($conn, $_POST['companyContact']);
    $pricingPlan = mysqli_real_escape_string($conn, $_POST['companyPricing']);
    $sql = "UPDATE user SET user_name='".$companyName."', user_addr='".$companyAddr."',user_contact='".$companyContact."',user_pricing_plan_id=".$pricingPlan." WHERE user_id=".$_GET['id'];
    if(mysqli_query($conn, $sql)) {
      echo "Company updated Successfully.";
    }
    else {
      echo "some error";
    }
  }


  $row = array();
  if(isset($_GET['id'])) {
    $sql = "SELECT * FROM user WHERE user_id=".$_GET['id'];
    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0) {
      $row = mysqli_fetch_assoc($result);
    }
    else {
      echo '<script>
        alert("No company found");
        window.location = "company.php";
      </script>';
    }
  }
  else {
    echo '<script>
      alert("GET variable not set");
      window.location = "company.php";
    </script>';
  }

?>

<div class="container" style="padding-top:10px;">
  <h2>Edit company Details</h2><hr>
  <form action="" method="POST">
      <div class="form-group">
        <label>Company Name</label>
        <input type="text" name="companyName" class="form-control" value="<?php echo $row['user_name']; ?>">
    </div>
    <div class="form-group">
      <label>Address</label>
      <input type="text" name="companyAddr" class="form-control" value="<?php echo $row['user_addr']; ?>" >
    </div>

    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Contact Number</label>
        <input type="text" name="companyContact" class="form-control" value="<?php echo $row['user_contact']; ?>">
      </div>
      <div class="form-group col-md-6">
        <label>Choose Pricing Plan</label>
        <select class="form-control" name="companyPricing">
          <option value="1" <?php if($row['user_pricing_plan_id'] == 1) echo "selected"; ?>>Basic</option>
          <option value="2" <?php if($row['user_pricing_plan_id'] == 2) echo "selected"; ?>>Standard</option>
          <option value="3" <?php if($row['user_pricing_plan_id'] == 3) echo "selected"; ?>>Premium</option>
        </select>
      </div>
    </div>
      <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
      <input type="submit" class="btn btn-success" value="Add new Company" name="updateCom">
  </form>
</div>

<!-- end here -->
<?php require('include/footer.inc.php'); ?>
