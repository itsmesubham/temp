<?php require('include/header.inc.php');
  $plan = array("Basic","Standard","Premium");
  $status = array("Deactive","Active");
?>

<?php
  if(isset($_POST['addCom'])) {
    $companyName = mysqli_real_escape_string($conn, $_POST['companyName']);
    $companyPwd = mysqli_real_escape_string($conn, $_POST['companyPwd']);
    $companyAddr = mysqli_real_escape_string($conn, $_POST['companyAddr']);
    $companyContact = mysqli_real_escape_string($conn, $_POST['companyContact']);
    $pricingPlan = mysqli_real_escape_string($conn, $_POST['companyPricing']);
    $sql = "insert into user (user_name, user_password, user_role, user_addr, user_status, user_contact, user_pricing_plan_id) values ('".$companyName."','".$companyPwd."',3,'".$companyAddr."',1,'".$companyContact."',".$pricingPlan.")";
    if(mysqli_query($conn, $sql)) {
      echo "Company Inserted Successfully.";
    }
  }


  if(isset($_GET['action'])) {
    // blocking a customer
    if($_GET['action'] == "block") {
      $sql = "UPDATE user SET user_status=0 WHERE user_id=".$_GET['id'];
      if(mysqli_query($conn,$sql)) {
        echo "Blocked Successfully";
        redirect('customer.php');
      }
      else {
        echo "Error in blocking";
      }
    }
    else if($_GET['action'] == "delete") {
      // // deleting the customer
      $sql = "DELETE FROM user WHERE user_id=".$_GET['id'];
      if(mysqli_query($conn,$sql)) {
        echo "Deleted Successfully";
        redirect('customer.php');
      }
      else {
        echo "Error in deletion";
      }
    }
  }
?>



  <div class="container cbody" style="padding-top:10px;">

    <div class="row">
      <div class="col-6">
        <button type="button" class="btn btn-lg btn-primary" data-toggle="modal" data-target="#exampleModalCenter">Add New Customer</button>
      </div>
      <div class="col-6">
        <!-- <?php
          if($isFlash) {
            echo $flashMsg;
          }
        ?> -->
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add a new Customer</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" method="POST">
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label>Company Name</label>
                  <input type="text" name="companyName" class="form-control" placeholder="Customer Name">
                </div>
                <div class="form-group col-md-6">
                  <label >Password</label>
                  <input type="text" name="companyPwd" class="form-control" placeholder="Password">
                </div>
              </div>
              <div class="form-group">
                <label>Address</label>
                <input type="text" name="companyAddr" class="form-control"  placeholder="Custoemr Address">
              </div>

              <div class="form-row">
                <div class="form-group col-md-6">
                  <label>Contact Number</label>
                  <input type="text" name="companyContact" class="form-control" placeholder="+91 98765-54321">
                </div>
                <div class="form-group col-md-6">
                  <label>Choose Pricing Plan</label>
                  <select class="form-control" name="companyPricing">
                    <option selected>Choose...</option>
                    <option value="1">Basic</option>
                    <option value="2">Standard</option>
                    <option value="3">Premium</option>
                  </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                <input type="submit" class="btn btn-success" value="Add new Company" name="addCom">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Model Ends here -->

          <?php
            $sql = 'SELECT * FROM user WHERE user_role=3';
            $result = mysqli_query($conn,$sql);
            $i = 1;
            if(mysqli_num_rows($result)>0) {
              echo '<table class="table table-striped table-bordered" style="margin-top:10px;">
                  <thead class="thead-dark">
                    <tr>
                      <th>S. No.</th>
                      <th>Company Name</th>
                      <th>Company Address</th>
                      <th>Company Contact</th>
                      <th>Pricing Plan</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>

                  <tbody>';

              while($row = mysqli_fetch_assoc($result)) {
                echo '
                  <tr>
                    <td>'.$i++.'. </td>
                    <td>'.$row['user_name'].'</td>
                    <td>'.$row['user_addr'].'</td>
                    <td>'.$row['user_contact'].'</td>
                    <td>'.$plan[$row['user_pricing_plan_id']].'</td>
                    <td>'.$status[$row['user_status']].'</td>
                    <td><a href="editCustomer.php?id='.$row['user_id'].'"><i class="far fa-edit"></i> Edit</a>&nbsp;&nbsp;
                    <a href="?action=block&id='.$row['user_id'].'"><i class="fa fa-ban"></i> block</a>&nbsp;&nbsp;
                    <a href="?action=delete&id='.$row['user_id'].'"><i class="fa fa-trash"></i> Delete</a></td>
                  </tr>
                ';
              }
            }
            else {
              echo "NO COMPANIES ADDED YET.";
            }
          ?>
        </tbody>
      </table>


  </div>


<?php require('include/footer.inc.php'); ?>
