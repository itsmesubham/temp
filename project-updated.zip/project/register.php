<?php
  require('config/db.inc.php');
  require('config/functions.inc.php');
?>

<?php
  $err = 0;
  $errMsg = "";
  $user_role = "";
  if(isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
    $cpwd = mysqli_real_escape_string($conn, $_POST['cpwd']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $radio = mysqli_real_escape_string($conn, $_POST['radio']);
    $addr = mysqli_real_escape_string($conn, $_POST['addr']);
    if($radio == 'client') {
      $role = 3;
      $age = mysqli_real_escape_string($conn, $_POST['age']);
      $gender = mysqli_real_escape_string($conn, $_POST['gender']);
      $creator = mysqli_real_escape_string($conn, $_POST['comId']);
    }
    else if($radio == 'company') {
      $role = 2;
      $age = 0;
      $gender = "";
      $creator = 0;
    }
    $status = 0;

    $register = $conn->prepare("INSERT INTO user (user_name, user_password, user_role, user_creator, user_addr, user_age, user_sex, user_status, user_contact, user_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $register->bind_param("ssiisisiss",$name, $pwd, $role, $creator,$addr, $age, $sex, $status, $contact, $email);

    if($register->execute()) {
      echo '<div class="col-md-6 m-auto">
          Registerd
        </div>';
    }
    else {
      print_r($register->error);
    }
    $register->close();

  }
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Project</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/super-admin.css">
  </head>
  <body>
    <div class="row mt-5">
      <div class="col-md-6 m-auto">
        <div class="card card-body bg-light">
          <h2 class="text-center mb-3">Register Now</h2><hr>
          <form action="" method="POST" autocomplete="off">
            <div class="row">
              <div class="col-6">
                <div class="form-group">
                  <label>User Name</label>
                  <input type="text" class="form-control" name="name" placeholder="Enter User Name">
                </div>
              </div>
              <div class="col-6">
                <div class="form-group">
                  <label>Email address</label>
                  <input type="email" class="form-control" name="email" placeholder="Enter email">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-6">
                <div class="form-group">
                  <label>Password</label>
                  <input type="password" class="form-control" name="pwd"  placeholder="Password">
                </div>
              </div>
              <div class="col-6">
                <div class="form-group">
                  <label for="exampleInputPassword1">Confirm Password</label>
                  <input type="password" class="form-control" name="cpwd" placeholder="Confirm Password">
                </div>
              </div>
            </div>
            <div class="form-group">
              <label>Address</label>
              <input type="text" class="form-control" name="addr"  placeholder="Address">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Contact No.</label>
              <input type="text" class="form-control" name="contact"  placeholder="Contact No.">
            </div>
            <div class="form-group">
              <label for="radio">Register As : &nbsp;</label>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="radio" id="inlineRadio1" value="company">
                <label class="form-check-label" for="inlineRadio1">Company</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="radio" id="inlineRadio2" value="client">
                <label class="form-check-label" for="inlineRadio2">Client</label>
              </div>
            </div>
            <div id="p2">
              <div class="form-group autocomplete">
                <label>Select Company</label>
                <div class="ui-widget">
                  <input class="form-control" type="text" name="comName" id="company" placeholder="Start typing the company name & select from dropdown">
                  <input type="hidden" name="comId" id="comId">
                </div>
              </div>
              <div class="row">
                <div class="col-6">
                  <div class="form-group">
                    <label>Age</label>
                    <input type="text" class="form-control" name="age" id="exampleInputPassword1" placeholder="Enter Age">
                  </div>
                </div>
                <div class="col-6">
                  <div class="form-group">
                    <label>Gender</label>
                    <label>Gender</label>
                    <select class="form-control" name="gender">
                      <option selected>Choose...</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Others">Others</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <button type="submit" name="register" class="btn btn-primary">Submit</button>
          </form>
          <p class="lead mt-2">
            Already Registered? <a href=".">Login</a>
          </p>
        </div>
      </div>
    </div>
  </body>
  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.js"></script>

  <script>
  $( function() {
    function log( message ) {
      $( "<div>" ).text( message ).prependTo( "#log" );
      $( "#log" ).scrollTop( 0 );
    }

    $( "#company" ).autocomplete({
      source: function( request, response ) {
        $.ajax( {
          url: "searchCom.php",
          data: 'query=' + request.term,
          dataType: "json",
          type: "POST",
          success: function( data ) {
            response(data)
          }
        } );
      },
      minLength: 2,
      select: function( event, ui ) {
        document.getElementById('comId').value = ui.item.id;
        //console.log(ui.item.id);
      }
    } );


  });
  </script>


</html>
