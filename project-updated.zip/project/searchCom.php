<?php
  $keyword = strval($_POST['query']);
  $conn =new mysqli('localhost', 'root', '' , 'project');
  $search_param = "{$keyword}%";
	$sql = $conn->prepare("SELECT user_id,user_name FROM user WHERE user_role=2 and user_name LIKE ?");
	$sql->bind_param("s",$search_param);
	$sql->execute();
	$result = $sql->get_result();
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
        $rowX['value'] = htmlentities(stripslashes($row['user_name']));
		    $rowX['id'] = (int)$row['user_id'];
        $row_set[] = $rowX;
		}
		echo json_encode($row_set);
	}
  else {
    return 0;
  }
	$conn->close();
?>
