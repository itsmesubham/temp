console.log('Hello Motherfucker');
