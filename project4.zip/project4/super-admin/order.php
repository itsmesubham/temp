<?php require('include/header.inc.php'); ?>
<!--  start here -->

<div class="container">
  <h1>Manage Orders Here</h1>
</div>

<!-- end here -->
<?php require('include/footer.inc.php'); ?>
