<?php require('include/header.inc.php'); ?>


<?php

if(isset($_GET['action'])) {
  // Approve A company
  if($_GET['action'] == "verify") {
    $sql = "UPDATE user SET user_status=1 WHERE user_id=".$_GET['id'];
    if(mysqli_query($conn,$sql)) {
      echo "Approved Successfully";
      redirect('.');
    }
    else {
      echo "Error while approving";
    }
  }
  else if($_GET['action'] == "delete") {
    // // deleting company
    $sql = "DELETE FROM user WHERE user_id=".$_GET['id'];
    if(mysqli_query($conn,$sql)) {
      echo "Deleted Successfully";
      redirect('.');
    }
    else {
      echo "Error in deletion";
    }
  }
}

?>


<div class="container">
  <h2>Pending Applications</h2><hr>

  <?php
    $query = "SELECT * FROM user WHERE user_role=2 and user_creator=0 and user_status=0";
    $result = mysqli_query($conn, $query);
    if(mysqli_num_rows($result)>0) {
      echo '
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Company Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
      ';
      while($row = mysqli_fetch_assoc($result)) {
        echo '<tr>
            <td>'.$row['user_name'].'</td>
            <td>'.$row['user_email'].'</td>
            <td>'.$row['user_contact'].'</td>
            <td>'.$row['user_addr'].'</td>
            <td><a href="?action=verify&id='.$row['user_id'].'"><i class="fa fa-check"></i> Approve</a>&nbsp;&nbsp;
            <a href="?action=delete&id='.$row['user_id'].'"><i class="fa fa-trash"></i> Delete</a></td>
          </tr>';
      }
      echo '</tbody>
        </table>';
    }
    else {
      echo "<h2>No Pending Application.</h2>";
    }
  ?>


</div>


<?php require('include/footer.inc.php'); ?>
