<?php require('include/header.inc.php'); ?>
<!--  start here -->

  <style media="screen">
    .ct2 {
      margin-top: 20px;
    }
    h2 {
      font-weight: 500;
      font-family: monospace;
      text-decoration: underline;
    }

    textarea {
      resize: none;
    }
  </style>

  <div class="container ct2">
    <div class="row">
      <div class="col-sm text-center">
        <h2>Update Password</h2>
        <br>
        <form>
          <div class="form-group">
            <input type="password" class="form-control" id="currentPwd" aria-describedby="emailHelp" placeholder="Enter current password">
          </div>
          <div class="form-group">
            <input type="password" class="form-control" placeholder="Enter New Password">
          </div>
          <div class="form-group">
            <input type="password" class="form-control" placeholder="Confirm New Password">
          </div>
          <button type="submit" class="btn btn-success btn-block">Update Password</button>
        </form>
      </div>


      <div class="col-sm text-center">
        <h2>Update Address</h2>
        <br>
        <form>
          <div class="form-group">
            <textarea name="name" class="form-control" rows="5" cols="80" placeholder="Enter your new address"></textarea>
          </div>
          <button type="submit" class="btn btn-success btn-block">Update Address</button>
        </form>
      </div>


      <div class="col-sm text-center">
        <h2>Update Details</h2><br>
        <form>
          <div class="form-group">
            <input type="text" class="form-control" id="currentPwd" aria-describedby="emailHelp" placeholder="New Contact Number">
          </div>
          <div class="form-group">
            <input type="text" class="form-control" placeholder="New email Address">
          </div>
          <div class="form-group">
            <input type="text" class="form-control" placeholder="Other detail update">
          </div>
          <button type="submit" class="btn btn-success btn-block">Update Details</button>
        </form>
      </div>
    </div>
  </div>

<!-- end here -->
<?php require('include/footer.inc.php'); ?>
