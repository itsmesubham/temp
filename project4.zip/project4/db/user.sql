-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 30, 2019 at 06:41 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(20) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_role` int(10) NOT NULL,
  `user_creator` int(20) NOT NULL,
  `user_addr` varchar(255) NOT NULL,
  `user_age` int(10) NOT NULL,
  `user_sex` varchar(50) DEFAULT NULL,
  `user_status` int(10) NOT NULL,
  `user_contact` varchar(50) NOT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_pricing_plan_id` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_password`, `user_role`, `user_creator`, `user_addr`, `user_age`, `user_sex`, `user_status`, `user_contact`, `user_email`, `user_pricing_plan_id`) VALUES
(1, 'admin', 'admin', 1, 0, 'india', 20, 'Male', 1, '+91 75248-51172', 'admin@admin.com', 1),
(12, 'varun', 'Varun@100', 2, 1, '1209204, b baker street', 0, '', 1, '3824989124', 'emai@gmail.com', 1),
(13, 'mnnit', '12345', 2, 1, 'allahabad', 0, '', 1, '21001023', NULL, 2),
(27, 'abfajsk', '123454', 3, 12, 'Varundfks;', 20, NULL, 1, '23532523', 'e1k2kel@fdmf.cp', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
