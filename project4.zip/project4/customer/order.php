<?php require('include/header.inc.php'); ?>
<!--  start here -->

<style media="screen">
  textarea {
    resize : none;
  }
</style>
<div class="container" style="padding-top:10px;">
  <h4><b>Create new outgoing delivery</b></h4><hr>
  <form method="POST" action="">
    <div class="form-row">
      <div class="form-group col-md-4">
        <h4><b>Your Information</b></h4><hr>
        <label for="orderer">Order Placer Details</label>
        <input type="text" class="form-control" name="oName" placeholder="firstname lastname">
        <input type="email" class="form-control"name="oEmail" placeholder="user@xyz.com">
        <input type="text" class="form-control" name="oContact" placeholder="">
        <br>
        <label for="readyTime">Ready Time & Date</label>
        <input class="form-control" type="datetime-local" name="oReady" placeholder="dd/mm/yyyy, hh:mm"><br>
        <label for="dueTime">Due Time & Date</label>
        <input class="form-control" type="datetime-local" name="oDue" placeholder="dd/mm/yyyy, hh:mm">
      </div>
      <div class="form-group col-md-4">
        <h4><b>Pickup & Destination Address</b></h4><hr>
        <label for="pickup address">Enter Pickup address details</label>
        <textarea class="form-control" name="oPickup" rows="5" placeholder="Recipient's name, Street address, floor/suite/apertment no. , state, country, pin code, phone no."></textarea><br>
        <label for="pickup address">Enter Destination address details</label>
        <textarea class="form-control" name="oDest" rows="5" placeholder="Recipient's name, Street address, floor/suite/apertment no. , state, country, pin code, phone no."></textarea>
      </div>
      <div class="form-group col-md-4">
        <h4><b>Other Details</b></h4><hr>
        <label for="">Service Fee</label>
        <input type="text" name="oService" class="form-control"><br>
        <label for="">Delivery Notes</label>
        <textarea class="form-control" name="oNotes" rows="9" placeholder="Special Instructions and notes related to order"></textarea>
      </div>
    </div>
    <div class="form-row">
      <div class="col-8"></div>
      <div class="col-4">
      <input type="submit" class="btn btn-lg btn-success btn-block" name="createOrder" value="Create Order">
      </div>
    </div>
  </form>
</div>

<!-- end here -->
<?php require('include/footer.inc.php'); ?>
