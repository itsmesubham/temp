<?php require('include/header.inc.php'); ?>
<!--  start here -->


<?php

  if(isset($_GET['action']) && $_GET['action'] == 'delete' ) {
    $sql = "DELETE FROM orders WHERE order_id=".$_GET['id'];
    if(mysqli_query($conn,$sql)) {
      echo '<script>
        alert("Order Deleted Successfully");
        window.location = "order.php";
      </script>
      ';
    }
    else {
      echo "Error in deletion";
    }
  }
  if(isset($_POST['update_order']) ) {
    $sql = "update orders set order_status= '".$_POST['order-status']."' WHERE order_id=".$_POST['order_id'].";";
    
    if(mysqli_query($conn,$sql)) {
      echo '<script>
        alert("Order status updated Successfully");
        window.location = "order.php";
      </script>
      ';
    }
    else {
      echo "Error in Changing order status";
    }
  }

?>

  
<div class="container">

  <hr>
  <h6><b>Previous Orders</b></h6>

  <?php
    $emailQuery ="SELECT user_email FROM USER WHERE user_id=".$_SESSION['user_id'];
    $emailRes = mysqli_query($conn,$emailQuery);
    $emailId = mysqli_fetch_assoc($emailRes);
     #var_dump($emailRes);
    $email = $emailId['user_email'];  
    $query = "SELECT * FROM orders WHERE order_by_email='".$email."'";
    
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result)>0) {
      while($row = mysqli_fetch_assoc($result)) {
        echo '<div class="card bg-secondary text-white">
                <div class="card-body">
                
                  <h4 class="card-title"><b> Order #'.$row['order_id'].'</b>  || '.$row['order_by_name'].' || '.$row['order_by_number'].' || '.$row['order_by_email'].'</h4>

                  <div class="row">
                    <div class="col-6">
                      <strong>Pick up addr : </strong> '.$row['pickupAddr'].'
                    </div>
                    <div class="col-6">
                      <strong>Des. Addr : </strong> '.$row['desAddr'].'
                    </div>
                    <div class="col-3">
                      <strong>Ready Date : </strong> '.$row['readyDate'].'
                    </div>
                    <div class="col-3">
                      <strong>Ready Time : </strong> '.$row['readyTime'].'
                    </div>
                    <div class="col-3">
                      <strong>Due Date : </strong> '.$row['dueDate'].'
                    </div>
                    <div class="col-3">
                      <strong>Due Time : </strong> '.$row['dueTime'].'
                    </div>
                    <div class="col-3">
                      <strong>Order Date : </strong> '.$row['order_date'].'
                    </div>
                    <div class="col-3">
                      <strong>Service Fee : </strong> '.$row['order_fee'].'
                    </div>
                    <div class="col-6">
                      <strong>Delivery Notes : </strong> '.$row['delivery_notes'].'
                    </div>
                     <div class="col-3">
                      <strong>Order Status : </strong> '.$row['order_status'].'
                    </div>
                  </div>
                  <br>
                 
 
                </div>
              </div><br>';
      }
    }
    else {
      echo "No Order placed till now.";
    }

  ?>





</div>



<!-- end here -->
<?php require('include/footer.inc.php'); ?>
