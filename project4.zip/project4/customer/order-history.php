<?php require('include/header.inc.php'); ?>
<!--  start here -->


<div class="container" style="padding-top:10px;">

  <form action="" method="post">
    <div class="form-row">
      <div class="col-md-3">
        <p>Select date to create invoice</p>
      </div>
      <div class="col-md-4">
        <input type="text" name="fol_date" class="form-control datetimepicker-input" id="datetimepicker2" data-toggle="datetimepicker" data-target="#datetimepicker2" placeholder="Select a Date"/>
      </div>
      <div class="col-md-3">
        <button type="button" class="btn btn-block btn-primary" name="button">Generate Invoices</button>
      </div>
    </div>
  </form>

  <hr>
</div>


<!-- end here -->
<?php require('include/footer.inc.php'); ?>
