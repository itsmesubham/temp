<?php require('include/header.inc.php'); ?>
<!--  start here -->

<?php
  //create order
  if(isset($_POST['createOrder'])) {
    //print_r($_POST);
    $createOrder = $conn->prepare("INSERT INTO orders (order_company, order_date, order_by_name, order_by_email, order_by_number, order_status, pickupAddr, desAddr, readyDate, readyTime, dueDate, dueTime, order_fee, delivery_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $createOrder->bind_param("issssissssssis",$oCompany,$oDate,$oName, $oEmail, $oContact, $oStatus, $oPickup, $oDest, $oReady, $oReadyTime, $oDue, $oDueTime, $oService, $oNotes);
    $oCompany = $_SESSION['user_id'];
    $oName = mysqli_real_escape_string($conn, $_POST['oName']);
    $oDate = date('Y-m-d h:m:s');
    $oStatus = 1;
    $oEmail = mysqli_real_escape_string($conn, $_POST['oEmail']);
    $oContact = mysqli_real_escape_string($conn, $_POST['oContact']);
    $oReady = mysqli_real_escape_string($conn, $_POST['readyDate']);
    $var = $oReady;
    $date = DateTime::createFromFormat('m/d/Y', $oReady);

    $oReady = $date->format('Y-m-d');;
    $oDue = mysqli_real_escape_string($conn, $_POST['dueDate']);
   $date = DateTime::createFromFormat('m/d/Y', $oDue);

    $oDue = $date->format('Y-m-d');;

    
    $oPickup = mysqli_real_escape_string($conn, $_POST['oPickup']);
    $oDest = mysqli_real_escape_string($conn, $_POST['oDest']);
    $oService = mysqli_real_escape_string($conn, $_POST['oService']);
    $oNotes = mysqli_real_escape_string($conn, $_POST['oNotes']);
    $readyTime = mysqli_real_escape_string($conn, $_POST['readyTime']);
    $dueTime = mysqli_real_escape_string($conn, $_POST['dueTime']);
    $oReadyTime = date("H:i", strtotime($readyTime));
    $oDueTime = date("H:i", strtotime($dueTime));
    print_r($_POST);
    if($createOrder->execute()) {
      echo '
        <script>
          alert("Order Has been created.");
          window.location = "order.php";
        </script>
      ';
    }
    else {
      echo $createOrder->error;
      echo "Error In creating order";
    }
    $createOrder->close();
  }
?>


<style media="screen">
  textarea {
    resize : none;
  }
</style>
<div class="container" style="padding-top:10px;">
  <h4><b>Create new outgoing delivery</b></h4><hr>
  <form method="POST" action="" autocomplete="off">
    <div class="form-row">
      <div class="form-group col-md-4">
        <h4><b>Your Information</b></h4><hr>
        <label for="orderer">Order Placer Details</label>
        <input type="text" class="form-control" name="oName" placeholder="Order Placer Name" value="varun">
        <input type="email" class="form-control"name="oEmail" placeholder="varun@routeid.co.in" value="varun@routeid.co.in">
        <input type="text" class="form-control" name="oContact" placeholder="+91 86966 - 08123" value="+91 86966 - 08123">
        <br>
        <label for="readyTime">Ready Time & Date</label>
        <div class="row">
          <div class="col-sm-6">
            <input type="text" name="readyDate" class="form-control datetimepicker-input" id="datetimepicker2" data-toggle="datetimepicker" data-target="#datetimepicker2" placeholder="Select a Date"/>
          </div>
          <div class="col-sm-6">
            <div class="input-group date" id="datetimepicker3" data-target-input="nearest">
              <input type="text" name="readyTime" class="form-control datetimepicker-input" data-target="#datetimepicker3" data-toggle="datetimepicker"/>
            </div>
          </div>
        </div>
        <br>
        <label for="dueTime">Due Time & Date</label>
        <div class="row">
          <div class="col-sm-6">
            <input type="text" name="dueDate" class="form-control datetimepicker-input" id="datetimepicker4" data-toggle="datetimepicker" data-target="#datetimepicker4" placeholder="Select a Date"/>
          </div>
          <div class="col-sm-6">
            <div class="input-group date"  id="datetimepicker5" data-target-input="nearest">
              <input type="text" name="dueTime" class="form-control datetimepicker-input" data-target="#datetimepicker5" data-toggle="datetimepicker"/>
            </div>
          </div>
        </div>
      </div>
      <div class="form-group col-md-4">
        <h4><b>Pickup & Destination Address</b></h4><hr>
        <label for="pickup address">Enter Pickup address details</label>
        <textarea class="form-control" name="oPickup" rows="5" placeholder="Recipient's name, Street address, floor/suite/apertment no. , state, country, pin code, phone no."></textarea><br>
        <label for="pickup address">Enter Destination address details</label>
        <textarea class="form-control" name="oDest" rows="5" placeholder="Recipient's name, Street address, floor/suite/apertment no. , state, country, pin code, phone no."></textarea>
      </div>
      <div class="form-group col-md-4">
        <h4><b>Other Details</b></h4><hr>
        <label for="">Service Fee</label>
        <input type="text" name="oService" class="form-control"><br>
        <label for="">Delivery Notes</label>
        <textarea class="form-control" name="oNotes" rows="9" placeholder="Special Instructions and notes related to order"></textarea>
      </div>
    </div>
    <div class="form-row">
      <div class="col-8"></div>
      <div class="col-4">
      <input type="submit" class="btn btn-lg btn-success btn-block" name="createOrder" value="Create Order">
      </div>
    </div>
  </form>
</div>


<!-- end here -->
<?php require('include/footer.inc.php'); ?>
