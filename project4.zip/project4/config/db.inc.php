<?php
  session_start();   // session things
  $serverName = "localhost";
  $dbUser = "root";
  $dbPassword = "s0num0nu";
  $dbName = "project";

  $conn = mysqli_connect($serverName,$dbUser,$dbPassword,$dbName);

  /************************************************************************
                        super-admin prepared statements starts here
  ************************************************************************/



  /************************************************************************
                        super-admin prepared statements ends here
  ************************************************************************/




  /************************************************************************
                        Admin prepared statements starts here
  ************************************************************************/

  // add a customer by a company



  // add a new plan
  

  /************************************************************************
                        Admin prepared statements ends here
  ************************************************************************/

?>
