<?php

  // function for secure login
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

  // redirect to specific URL
  function redirect($url, $statusCode = 303) {
     header('Location: ' . $url, true, $statusCode);
     die();
  }
?>
