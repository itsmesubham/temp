<?php require('include/header.inc.php');
  $plan = array("Basic","Standard","Premium");
  $status = array("Deactive","Active");
?>

<?php

  if(isset($_GET['action'])) {
    // blocking a pricing plan
    if($_GET['action'] == "block") {
      $sql = "UPDATE pricing SET plan_status=0 WHERE pricing_id=".$_GET['id'];
      if(mysqli_query($conn,$sql)) {
        echo "Blocked Successfully";
        redirect('pricing.php');
      }
      else {
        echo "Error in blocking";
      }
    }
    else if($_GET['action'] == "delete") {
      // // deleting the pricing plan
      $sql = "DELETE FROM pricing WHERE pricing_id=".$_GET['id'];
      if(mysqli_query($conn,$sql)) {
        echo "Deleted Successfully";
        redirect('pricing.php');
      }
      else {
        echo "Error in deletion";
      }
    }
  }


  if(isset($_POST['addPlan'])) {
    $addPlan = $conn->prepare("INSERT INTO pricing (plan_name, vehicle, time, distance, amount, plan_status) VALUES (?, ?, ?, ?, ?, ?)");
    $addPlan->bind_param("sssddd", $pName, $pVehicle, $pTime, $pDistance, $pAmount, $pStatus);
    $pName = mysqli_real_escape_string($conn, $_POST['planName']);
    $pVehicle = mysqli_real_escape_string($conn, $_POST['vehicle']);
    $pTime = mysqli_real_escape_string($conn, $_POST['time']);
    $pDistance = mysqli_real_escape_string($conn, $_POST['distance']);
    $pAmount = mysqli_real_escape_string($conn, $_POST['amount']);
    $pStatus = 1;
    if($addPlan->execute()) {
      echo "New Plan Created Successfully.";
      unset($_POST);
    }
    else {
    echo  $addPlan->error;
      echo "Some Error";
    }
    $addPlan->close();
  }
?>



  <div class="container cbody" style="padding-top:10px;">

    <div class="row">
      <div class="col-6">
        <button type="button" class="btn btn-lg btn-primary" data-toggle="modal" data-target="#exampleModalCenter">Add New Pricing</button>
      </div>
      <div class="col-6">
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add a New Pricing Plan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" method="POST">
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label>Plan Name</label>
                  <input type="text" name="planName" class="form-control" placeholder="Pricing Plan Name">
                </div>
                <div class="form-group col-md-6">
                  <label>Vehicle</label>
                  <input type="text" name="vehicle" class="form-control" placeholder="Vehicle Name">
                </div>
              </div>
              <div class="form-row">
                <div class="form-group col-md-4">
                  <label>Time</label>
                  <input type="text" name="time" class="form-control" placeholder="+91 98765-54321">
                </div>
                <div class="form-group col-md-4">
                  <label>Distance</label>
                  <input type="text" name="distance" class="form-control" placeholder="Distance">
                </div>
                <div class="form-group col-md-4">
                  <label>Amount</label>
                  <input type="text" name="amount" class="form-control" placeholder="Amount">
                </div>
              </div>
              <div class="form-group">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="isChecked">
                  <label class="form-check-label" for="gridCheck">
                    Check me out
                  </label>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                <input type="submit" class="btn btn-success" value="Add New Pricing Plan" name="addPlan">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

          <?php
            $sql = 'SELECT * FROM pricing WHERE 1';
            $result = mysqli_query($conn,$sql);
            $i = 1;
            if(mysqli_num_rows($result)>0) {
              echo '<table class="table table-striped table-bordered" style="margin-top:10px;">
                      <thead class="thead-dark">
                        <tr>
                          <th>S. No.</th>
                          <th>Plan Name</th>
                          <th>Vehicle</th>
                          <th>Amount</th>
                          <th>Time</th>
                          <th>Distance</th>
                          <th>Status</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>';

              while($row = mysqli_fetch_assoc($result)) {
                echo '
                  <tr>
                    <td>'.$i++.'. </td>
                    <td>'.$row['plan_name'].'</td>
                    <td>'.$row['vehicle'].'</td>
                    <td>'.$row['amount'].'</td>
                    <td>'.$row['time'].'</td>
                    <td>'.$row['distance'].'</td>
                    <td>'.$status[$row['plan_status']].'</td>
                    <td><a href="editPricingPlan.php?id='.$row['pricing_id'].'"><i class="far fa-edit"></i> Edit</a>&nbsp;&nbsp;
                    <a href="?action=block&id='.$row['pricing_id'].'"><i class="fa fa-ban"></i> block</a>&nbsp;&nbsp;
                    <a href="?action=delete&id='.$row['pricing_id'].'"><i class="fa fa-trash"></i> Delete</a></td>
                  </tr>
                ';
              }
            }
            else {
              echo "0 Pricing Plans available Now.";
            }
          ?>
        </tbody>
      </table>


  </div>


<?php require('include/footer.inc.php'); ?>
