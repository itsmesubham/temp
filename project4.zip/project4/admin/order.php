<?php require('include/header.inc.php'); ?>

<?php

  if(isset($_GET['action']) && $_GET['action'] == 'delete' ) {
    $sql = "DELETE FROM orders WHERE order_id=".$_GET['id'];
    if(mysqli_query($conn,$sql)) {
      echo '<script>
        alert("Order Deleted SUccessfully");
        window.location = "order.php";
      </script>
      ';
    }
    else {
      echo "Error in deletion";
    }
  }

?>


<div class="container">
  <div class="mt-2 mb-2">
    <div class="col-6">
      <a type="button" class="btn btn-lg btn-primary" href="create-order.php">Create New Order</a>
    </div>
  </div>
  <hr>
  <h6><b>Previous Orders</b></h6>

  <?php
    $query = "SELECT * FROM orders WHERE order_company=".$_SESSION['user_id'];
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result)>0) {
      while($row = mysqli_fetch_assoc($result)) {
        echo '<div class="card bg-secondary text-white">
                <div class="card-body">
                  <h4 class="card-title"><b> Order #'.$row['order_id'].'</b>  || '.$row['order_by_name'].' || '.$row['order_by_number'].' || '.$row['order_by_email'].'</h4>

                  <div class="row">
                    <div class="col-6">
                      <strong>Pick up addr : </strong> '.$row['pickupAddr'].'
                    </div>
                    <div class="col-6">
                      <strong>Des. Addr : </strong> '.$row['desAddr'].'
                    </div>
                    <div class="col-3">
                      <strong>Ready Date : </strong> '.$row['readyDate'].'
                    </div>
                    <div class="col-3">
                      <strong>Ready Time : </strong> '.$row['readyTime'].'
                    </div>
                    <div class="col-3">
                      <strong>Due Date : </strong> '.$row['dueDate'].'
                    </div>
                    <div class="col-3">
                      <strong>Due Time : </strong> '.$row['dueTime'].'
                    </div>
                    <div class="col-3">
                      <strong>Order Date : </strong> '.$row['order_date'].'
                    </div>
                    <div class="col-3">
                      <strong>Service Fee : </strong> '.$row['order_fee'].'
                    </div>
                    <div class="col-6">
                      <strong>Delivery Notes : </strong> '.$row['delivery_notes'].'
                    </div>
                  </div>
                  <br>
                  <a href="?action=delete&id='.$row['order_id'].'" class="card-link">Delete Order</a>
                </div>
              </div><br>';
      }
    }
    else {
      echo "No Order placed till now.";
    }

  ?>





</div>


<?php require('include/footer.inc.php'); ?>
