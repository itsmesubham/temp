<?php require('include/header.inc.php'); ?>
<!--  start here -->

<?php
  $err = 0;
  $errMsg = "";
  $scc = 0;
  $sccMsg = "";
  if(isset($_POST['saveDetails'])) {
    $comName = mysqli_real_escape_string($conn,$_POST['comName']);
    $comEmail = mysqli_real_escape_string($conn,$_POST['comEmail']);
    $comAddr = mysqli_real_escape_string($conn,$_POST['comAddr']);
    $comCon = mysqli_real_escape_string($conn,$_POST['comCon']);
    $query = "UPDATE user SET user_name='".$comName."', user_email='".$comEmail."',user_addr='".$comAddr."', user_contact='".$comCon."' WHERE user_id=".$_SESSION['user_id'];
    if(mysqli_query($conn,$query)) {
      $scc = 1;
      $sccMsg = "Details Successfully updated";
    }
    else {
      $err = 1;
      $errMsg = "Error while updating details";
    }
  }
?>


<?php
  $query = "SELECT * FROM user WHERE user_id='".$_SESSION['user_id']."'";
  $result = mysqli_query($conn,$query);
  if(mysqli_num_rows($result)>0) {
    $data = mysqli_fetch_assoc($result);
  }

  else {
    echo "Something went wrong, Contact Administrator";
  }
?>

<div>
  <div class="row mt-2">
    <div class="col-md-6 m-auto">
      <div class="card card-body bg-light">
        <h2 class="text-center mb-3"><i class="fas fa-user"></i>    View & Edit Company Details</h2>
        <form action="" method="POST">
          <div class="form-group">
            <label for="username">Company Name</label>
            <input type="text" id="email" name="comName" class="form-control" value="<?php echo $data['user_name']; ?>"/>
          </div>
          <div class="form-group">
            <label for="user email">Company Email</label>
            <input type="text" id="email" name="comEmail" class="form-control" value="<?php echo $data['user_email']; ?>"/>
          </div>
          <div class="form-group">
            <label for="user email">Company Address</label>
            <input type="text" id="email" name="comAddr" class="form-control" value="<?php echo $data['user_addr']; ?>"/>
          </div>
          <div class="form-group">
            <label for="user email">Company Contact</label>
            <input type="text" id="email" name="comCon" class="form-control" value="<?php echo $data['user_contact']; ?>"/>
          </div>
          <input type="submit" name="saveDetails" class="btn btn-primary btn-block" value="Save Details">
        </form>

        <br>
        <?php
        if($scc) {
          echo '<div class="alert alert-success" role="alert">
                '.$sccMsg.'
                </div>';
        }
        else if ($err) {
          echo '<div class="alert alert-danger" role="alert">
                  '.$errMsg.'
                </div>';
        }

        ?>
      </div>
    </div>
  </div>
</div>


<!-- end here -->
<?php require('include/footer.inc.php'); ?>
